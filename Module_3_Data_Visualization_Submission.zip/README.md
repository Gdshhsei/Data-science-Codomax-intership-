# Module 3 – Data Visualization Submission

1. Open Google Colab.
2. Upload `Module_3_Data_Visualization_Project.ipynb`.
3. Upload `retail_sales_visualization.csv`.
4. Run all cells.
5. Share the notebook as **Anyone with the link – Viewer**.
6. Submit the Colab link in Intern Works.
7. Publish `LinkedIn_Post.txt` on LinkedIn and submit the post URL.
8. Mark Module 3 as Done.

The project covers bar, line, pie, histogram and scatter plots plus regional/profit analysis.