# Module 2 Submission – Retail Sales Data Analysis with Python

## Submission Deliverables
- `Module_2_Retail_Sales_Data_Analysis.ipynb` – submission-ready Google Colab/Jupyter notebook
- `retail_sales_raw.csv` – dataset used by the notebook
- `LinkedIn_Post.txt` – ready-to-post LinkedIn content

## How to Submit on Google Colab
1. Open Google Colab.
2. Upload `Module_2_Retail_Sales_Data_Analysis.ipynb`.
3. Upload `retail_sales_raw.csv` in the Colab Files panel.
4. Run all cells from top to bottom.
5. Click **Share** → set access to **Anyone with the link** (Viewer).
6. Copy the Colab link and submit it in the Intern Works dashboard.
7. Publish the LinkedIn post and submit the LinkedIn post URL.
8. Mark the module as done.

## Project Title
Retail Sales Data Analysis with Python

## Technologies
Python, Pandas, NumPy, Google Colab

## Skills Demonstrated
Data import, data exploration, missing-value handling, duplicate removal, feature engineering, aggregation, KPI calculation, product/category/region analysis and basic business insights.
